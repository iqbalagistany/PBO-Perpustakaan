package pinjambuku;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;

public class pinjamDAOimp implements pinjamDAO {

    private koneksi con = new koneksi();
    private Statement s;
    private PreparedStatement ps;   //digunakan untuk menampung query yg blm lengkap datanya (yg msh ada tanda tanya)
    private ResultSet rs;
    private DefaultTableModel dtm;
    private final String[] column = {"ID PEMINJAMAN", "TANGGAL PINJAM", "ID BUKU", "ID ANGGOTA", "ID PETUGAS"};

    private String view = "select * from peminjaman";
    private String insert = "insert into peminjaman (id_peminjaman, tanggal_pinjam,"
            + "id_buku, id_anggota, id_petugas) values (?, ?, ?, ?, ?)";
    private String update = "update petugas set tanggal_pinjam=?,"
            + " id_buku=?, id_anggota=?, id_petugas=?  where id_peminjaman=?";
    private String delete = "delete from peminjaman where id_peminjaman=?";

    @Override
    public void read(JTable TBPINJAM) {
        try {
            dtm = new DefaultTableModel(null, column);
            s = con.getCon().createStatement();
            rs = s.executeQuery(view);  //eksekusi yg tdk merubah isi tabel
            while (rs.next()) {
                Object[] col = new Object[5];
                col[0] = rs.getInt("id_peminjaman");
                col[1] = rs.getString("tanggal_pinjam");
                col[2] = rs.getString("id_buku");
                col[3] = rs.getString("id_anggota");
                col[4] = rs.getInt("id_petugas");
                dtm.addRow(col);
            }
            TBPINJAM.setModel(dtm);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void create(pinjam pinjambuku) {
         try {
            ps = con.getCon().prepareStatement(insert);
            
            ps.setString(1, String.valueOf(pinjambuku.getTanggal_pinjam()));
            ps.setString(2, String.valueOf( pinjambuku.getId_buku()));
            ps.setString(3, String.valueOf( pinjambuku.getId_anggota()));
            ps.setString(4, String.valueOf(pinjambuku.getId_petugas()));
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Tambah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void update(pinjam pinjambuku) {
        try {
            ps = con.getCon().prepareStatement(update);
            ps.setDate(1, (pinjambuku.getTanggal_pinjam()));
            ps.setString(2, String.valueOf( pinjambuku.getId_buku()));
            ps.setString(3, String.valueOf( pinjambuku.getId_anggota()));
            ps.setString(4, String.valueOf(pinjambuku.getId_petugas()));
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Ubah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void delete(int id) {
       try {
            ps = con.getCon().prepareStatement(delete);
            ps.setString(1, String.valueOf(id));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Hapus data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

}
