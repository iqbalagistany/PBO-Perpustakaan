/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pinjambuku;

import javax.swing.JTable;

/**
 *
 * @author iqbal
 */
public interface pinjamDAO {
    
    public void read(JTable TBPINJAM);
    public void create(pinjam pinjambuku);
    public void update(pinjam pinjambuku);
    public void delete (int id);
}
