
package SignUpAnggota;


public class SignUp {
   
    private int id_anggota;
    private String username;
    private String password;
    private String nama_anggota;
    private String jurusan_anggota;
    private String no_telp_anggota;
    private String alamat_anggota;

    public int getId_anggota() {
        return id_anggota;
    }

    public void setId_anggota(int id_anggota) {
        this.id_anggota = id_anggota;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNama_anggota() {
        return nama_anggota;
    }

    public void setNama_anggota(String nama_anggota) {
        this.nama_anggota = nama_anggota;
    }

    public String getJurusan_anggota() {
        return jurusan_anggota;
    }

    public void setJurusan_anggota(String jurusan_anggota) {
        this.jurusan_anggota = jurusan_anggota;
    }

    public String getNo_telp_anggota() {
        return no_telp_anggota;
    }

    public void setNo_telp_anggota(String no_telp_anggota) {
        this.no_telp_anggota = no_telp_anggota;
    }

    public String getAlamat_anggota() {
        return alamat_anggota;
    }

    public void setAlamat_anggota(String alamat_anggota) {
        this.alamat_anggota = alamat_anggota;
    }
    
    
    
    
    
    
}
