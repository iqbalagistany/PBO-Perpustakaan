/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

/**
 *
 * @author HP
 */
public class login2 {

    public static boolean AUTH;
    public static int USER_ID;
    public static String NAMA;
    public static String STATUS;

}
