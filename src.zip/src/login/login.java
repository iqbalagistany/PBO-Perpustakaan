package login;

public class login {

    public static boolean AUTH;
    public static int USER_ID;
    public static String NAMA;
    public static String STATUS;

}