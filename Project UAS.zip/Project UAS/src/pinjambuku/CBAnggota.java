
package pinjambuku;

public class CBAnggota {
    
    private int id_anggota;
    private String nama_anggota;
    private String alamat_anggota;
    private String no_hp_anggota;

    public int getId_anggota() {
        return id_anggota;
    }

    public void setId_anggota(int id_anggota) {
        this.id_anggota = id_anggota;
    }

    public String getNama_anggota() {
        return nama_anggota;
    }

    public void setNama_anggota(String nama_anggota) {
        this.nama_anggota = nama_anggota;
    }

    public String getAlamat_anggota() {
        return alamat_anggota;
    }

    public void setAlamat_anggota(String alamat_anggota) {
        this.alamat_anggota = alamat_anggota;
    }

    public String getNo_hp_anggota() {
        return no_hp_anggota;
    }

    public void setNo_hp_anggota(String no_hp_anggota) {
        this.no_hp_anggota = no_hp_anggota;
    }
    
    
    
}
