package pinjambuku;

import java.util.logging.Level;
import java.util.logging.Logger;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;

public class pinjamDAOimp implements pinjamDAO {

    private koneksi con = new koneksi();
    private Statement s;
    private PreparedStatement ps;   //digunakan untuk menampung query yg blm lengkap datanya (yg msh ada tanda tanya)
    private ResultSet rs;
    private DefaultTableModel dtm;
    private final String[] column = {"ID PEMINJAMAN", "TANGGAL PINJAM", "ID BUKU", "ID ANGGOTA", "ID PETUGAS"};

    private String view = "select * from peminjaman";
    private String insert = "insert into peminjaman (tanggal_pinjam,"
            + "id_buku, id_anggota, id_petugas) values (?, ?, ?, ?)";
    private String update = "update petugas set tanggal_pinjam=?,"
            + " id_buku=?, id_anggota=?, id_petugas=?  where id_peminjaman=?";
    private String delete = "delete from peminjaman where id_peminjaman=?";

    private String sqlag = "select * from anggota";
    private String sqlpt = "select * from petugas";
    private String sqlbk = "select * from buku";
    
    @Override
    public void read(JTable TBPINJAM) {
        try {
            dtm = new DefaultTableModel(null, column);
            s = con.getCon().createStatement();
            rs = s.executeQuery(view);  //eksekusi yg tdk merubah isi tabel
            while (rs.next()) {
                Object[] col = new Object[5];
                col[0] = rs.getInt("id_peminjaman");
                col[1] = rs.getDate("tanggal_pinjam");
                col[2] = rs.getInt("id_buku");
                col[3] = rs.getInt("id_anggota");
                col[4] = rs.getInt("id_petugas");
                dtm.addRow(col);
            }
            TBPINJAM.setModel(dtm);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void create(pinjam pinjambuku) {
         try {
            ps = con.getCon().prepareStatement(insert);
            
            ps.setString(1, String.valueOf(pinjambuku.getTanggal_pinjam()));
            ps.setInt(2, pinjambuku.getId_buku());
            ps.setInt(3, pinjambuku.getId_anggota());
            ps.setInt(4, pinjambuku.getId_petugas());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Tambah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void update(pinjam pinjambuku) {
        try {
            ps = con.getCon().prepareStatement(update);
            ps.setDate(1, (pinjambuku.getTanggal_pinjam()));
            ps.setInt(2, pinjambuku.getId_buku());
            ps.setInt(3,pinjambuku.getId_anggota());
            ps.setInt(4, pinjambuku.getId_petugas());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Ubah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void delete(int id) {
       try {
            ps = con.getCon().prepareStatement(delete);
            ps.setString(1, String.valueOf(id));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Hapus data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public List<CBAnggota> Anggota() {
         //instansiasi barangList
        List<CBAnggota> agt = new ArrayList<>();
        
        try {
            
            s = con.getCon().createStatement();
            rs = s.executeQuery(sqlag);
            
            //proses pengisian barangList
            while(rs.next()){
              CBAnggota anggota = new CBAnggota();
              anggota.setId_anggota(rs.getInt("id_anggota"));
              anggota.setNama_anggota(rs.getString("nama_anggota"));
              anggota.setAlamat_anggota(rs.getString("alamat_anggota"));
              anggota.setNo_hp_anggota(rs.getString("no_telp_anggota"));
              
              agt.add(anggota);
            }
        } catch (Exception ex) {
            Logger.getLogger(pinjamDAOimp.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        //pengembalian nilai supplierList
        return agt;
    }

    @Override
    public List<CBbuku> Buku() {
         //instansiasi barangList
        List<CBbuku> bk = new ArrayList<>();
        
        try {
            
            s = con.getCon().createStatement();
            rs = s.executeQuery(sqlbk);
            
            //proses pengisian barangList
            while(rs.next()){
              CBbuku buku = new CBbuku();
              buku.setId_buku(rs.getInt("id_buku"));
              buku.setJudul_buku(rs.getString("judul_buku"));
              buku.setPenulis_buku(rs.getString("penulis_buku"));
             
              
              bk.add(buku);
            }
        } catch (Exception ex) {
            Logger.getLogger(pinjamDAOimp.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        //pengembalian nilai supplierList
        return bk;
    }

    @Override
    public List<CBpetugas> Petugas() {
         //instansiasi barangList
        List<CBpetugas> pt = new ArrayList<>();
        
        try {
            
            s = con.getCon().createStatement();
            rs = s.executeQuery(sqlpt);
            
            //proses pengisian barangList
            while(rs.next()){
              CBpetugas petugas = new CBpetugas();
              petugas.setId_petugas(rs.getInt("id_petugas"));
              petugas.setNama_petugas(rs.getString("nama_petugas"));
              petugas.setJabatan_petugas(rs.getString("jabatan_petugas"));
             
              
              pt.add(petugas);
            }
        } catch (Exception ex) {
            Logger.getLogger(pinjamDAOimp.class.getName()).log(Level.SEVERE, null, ex);
        }
           
        //pengembalian nilai supplierList
        return pt;
    }

}
