package pinjambuku;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import main.FormMenuUtama;

public class pinjamForm extends javax.swing.JFrame {

    private pinjamDAO dao;
    private Statement st;
    private Connection Con;
    private ResultSet RsBuku;
    private ResultSet RsAnggota;
    private ResultSet Rs;
    private ResultSet RsPetugas;
    private int id;

    private int tag;
//private ResultSet RsJual;
//private ResultSet RsDetail;
    // private ResultSet RsPeminjaman;
    //  public String kodepinjam, kodepetugas, namapetugas, kodeanggota, namaanggota;
//public int jumlahpinjam;
    private String Tanggal = "";
    private String Sql = "";

    public pinjamForm() {
        initComponents();

        dao = new pinjamDAOimp();
        reset();
    }

    public void reset() {
        tag = 0;

        JTANGGAL.cleanup();
        TXTNAMAPETUGAS.setText("");
        TXTJABATAN.setText("");
        TXTNAMAANGGOTA.setText("");
        TXTALAMAT.setText("");
        TXTNOHP.setText("");
        TXTJUDULBUKU.setText("");
        TXTPENGARANG.setText("");
        JTANGGAL.setDate(null);
        CBBUKU.setSelectedItem(null);
        CBANGGOTA.setSelectedItem(null);
        CBPETUGAS.setSelectedItem(null);

        read();
    }

    public void read() {
        dao.read(TBPINJAM);
    }

    public boolean validasi() {
        boolean hasil = false;
        if (TXTNAMAPETUGAS.getText().isEmpty() || TXTJABATAN.getText().isEmpty()
                || TXTNAMAANGGOTA.getText().isEmpty() || TXTALAMAT.getText().isEmpty() || TXTNOHP.getText().isEmpty()
                || TXTJUDULBUKU.getText().isEmpty() || TXTPENGARANG.getText().isEmpty()) {
            //tidak valid
            hasil = false;
        } else {
            //valid
            hasil = true;
        }
        return hasil;
    }

    private void PilihPetugas() {
        CBPETUGAS.removeAllItems();
        CBPETUGAS.addItem("Select");

        try {

            //String Sql = "SELECT*FROM petugas";
            Statement st = Con.createStatement();
            Sql = "select * from petugas "; //+ 
            RsPetugas = st.executeQuery(Sql);
            while (RsPetugas.next()) {
                CBPETUGAS.addItem(RsPetugas.getString("id_petugas"));
                //String AliasKode = RsPetugas.getString("id_Petugas");
                //CBPETUGAS.addItem(AliasKode);
                TXTNAMAPETUGAS.setText(RsPetugas.getString("nama_petugas"));
                TXTJABATAN.setText(RsPetugas.getString("jabatan_petugas"));
            }
            
            RsPetugas.last();
            //int jumlahdata - RsPetugas.getRow();
            RsPetugas.first();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Gagal Menampilkan Id Petugas\n" + e.getMessage());
        }

    }

    private void PilihBuku() {
        CBBUKU.removeAllItems();
        CBBUKU.addItem("Select");
        try {
            String Sql = "SELECT*FROM buku";
            Statement st = Con.createStatement();
            RsBuku = st.executeQuery(Sql);
            while (RsBuku.next()) {
                String AliasKode = RsBuku.getString("id_buku");
                CBBUKU.addItem(AliasKode);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Gagal Menampilkan Id buku\n" + e.getMessage());
        }
    }

    private void PilihAnggota() {
        CBANGGOTA.removeAllItems();
        CBANGGOTA.addItem("Select");
        try {
            String Sql = "SELECT*FROM anggota";
            Statement st = Con.createStatement();
            RsAnggota = st.executeQuery(Sql);
            while (RsAnggota.next()) {
                String AliasKode = RsAnggota.getString("id_anggota");
                CBANGGOTA.addItem(AliasKode);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Gagal Menampilkan Id anggota\n" + e.getMessage());
        }
    }

    public void Waktu() {
        Date tgl = new Date();
        JTANGGAL.setDate(tgl);
    }

    public void create() {
        pinjam pj = new pinjam();
        pj.setTanggal_pinjam((java.sql.Date) JTANGGAL.getDate());
        pj.setId_buku((int) CBBUKU.getSelectedItem());
        pj.setId_anggota((int) CBANGGOTA.getSelectedItem());
        pj.setId_petugas((int) CBPETUGAS.getSelectedItem());

        dao.create(pj);
    }

    public void update() {
        pinjam pj = new pinjam();
        pj.setId_peminjaman(id);
        pj.setTanggal_pinjam((java.sql.Date) JTANGGAL.getDate());
        pj.setId_buku((int) CBBUKU.getSelectedItem());
        pj.setId_anggota((int) CBANGGOTA.getSelectedItem());
        pj.setId_petugas((int) CBPETUGAS.getSelectedItem());

        dao.update(pj);
    }

    public void save() {
        //cek validasi
        if (validasi() == true) {
            if (tag == 0) {
                //create
                create();
            } else if (tag == 1) {
                //update
                update();
            }
            reset();
        } else {
            JOptionPane.showMessageDialog(rootPane, "Input belum lengkap!");
        }
    }

    public void ubah() {
        int selected = TBPINJAM.getSelectedRowCount();
        if (selected > 0) {
            int conf = JOptionPane.NO_OPTION;
            conf = JOptionPane.showConfirmDialog(rootPane, "Yakin untuk mengubah?",
                    "Confirm!", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                //update data
                tag = 1;
                int baris = TBPINJAM.getSelectedRow();
                id = Integer.valueOf(TBPINJAM.getValueAt(baris, 0).toString());
                JTANGGAL.setDateFormatString(TBPINJAM.getValueAt(baris, 1).toString());
                CBBUKU.setSelectedItem(TBPINJAM.getValueAt(baris, 2).toString());
                CBANGGOTA.setSelectedItem(TBPINJAM.getValueAt(baris, 3).toString());
                CBPETUGAS.setSelectedItem(TBPINJAM.getValueAt(baris, 4).toString());

            }

        } else {
            JOptionPane.showMessageDialog(rootPane, "Tidak ada data yang dipilih!");
        }
    }

    public void delete() {
        int selected = TBPINJAM.getSelectedRowCount();
        if (selected > 0) {
            int conf = JOptionPane.NO_OPTION;
            conf = JOptionPane.showConfirmDialog(rootPane, "Yakin untuk menghapus?",
                    "Confirm!", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                int baris = TBPINJAM.getSelectedRow();
                id = Integer.valueOf(TBPINJAM.getValueAt(baris, 0).toString());
                dao.delete(id);
                reset();
            }

        } else {
            JOptionPane.showMessageDialog(rootPane, "Tidak ada data yang dipilih!");
        }
    }

//    private void prosestambah() {
//        try {
//            DefaultTableModel tableModel = (DefaultTableModel) TPINJAM1.getModel();
//            String[] data = new String[5];
//            data[0] = String.valueOf(CBBUKU.getSelectedItem());
//            data[1] = TXTJUDULBUKU.getText();
//            data[2] = TXTPENGARANG.getText();
//            //data[3]= TXTJUMLAHPINJAM.getText();
//            tableModel.addRow(data);
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Error masukkan data \n" + e.getMessage());
//        }
//    }
//    private void simpandetail() {
//        int jumlah_baris = TPINJAM1.getRowCount();
//        if (jumlah_baris == 0) {
//            JOptionPane.showMessageDialog(rootPane, "Table is empty!!");
//        } else {
//            try {
//                int i = 0;
//                while (i < jumlah_baris) {
//                    st.executeUpdate("insert into peminjaman"
//                            + "(id_peminjaman,tanggal_pimjam ,id_buku,id_anggota,id_petugas)"
//                            + "values('" + TXTKODEPINJAM.getText() + "',"
//                            + "'" + TPINJAM1.getValueAt(i, 0) + "',"
//                            + "'" + TXTJUDULBUKU.getText() + "',"
//                            + "'" + TXTPENGARANG.getText() + "',"
//                            + "')");
//                    i++;
//                }
//            } catch (Exception e) {
//                JOptionPane.showMessageDialog(rootPane, "Gagal Menyimpan..!!" + e);
//            }
//        }
//    }
//    private void tampilpeminjaman() {
//        DefaultTableModel grid = new DefaultTableModel();
//        grid.addColumn("No");
//        grid.addColumn("Kode_pinjam");
//        grid.addColumn("Tanggal_Pinjam");
//        grid.addColumn("Kode_Petugas");
//        grid.addColumn("Nama_petugas");
//        grid.addColumn("Kode Anggota");
//        grid.addColumn("Nama_Anggota");
//        grid.addColumn("Jumlah Pinjam");
//        try {
//            int i = 1;
//            st = Con.createStatement();
//            Rs = st.executeQuery("SELECT*FROM tb_peminjam");
//            while (Rs.next()) {
//                grid.addRow(new Object[]{
//                    ("" + i++), Rs.getString(1), Rs.getString(2), Rs.getString(3),
//                    Rs.getString(4), Rs.getString(5), Rs.getString(6), Rs.getString(7)
//                });
//                TBPINJAM.setModel(grid);
//                TBPINJAM.enable(false);
//                BTNSIMPAN.requestFocus();
//            }
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Gagal Tampil" + e);
//        }
//    }
//    private void kosongkan() {
//        //TXTKODEPINJAM.setText("");
//        
//        TXTNAMAANGGOTA.setText("");
//        TXTALAMAT.setText("");
//        TXTNOHP.setText("");
//        
//        TXTNAMAPETUGAS.setText("");
//        TXTJABATAN.setText("");
//        
//        TXTJUDULBUKU.setText("");
//        TXTPENGARANG.setText("");
//        // TXTJUMLAHPINJAM.setText("");
//    }
//    private void hapustable() {
//        DefaultTableModel model = (DefaultTableModel) TPINJAM1.getModel();
//
//        while (model.getRowCount() > 0) {
//            for (int i = 0; i < model.getRowCount(); ++i) {
//                model.removeRow(i);
//            }
//        }
//    }
//    public void delete() {
//        int selected = TBPINJAM.getSelectedRowCount();
//        if (selected > 0) {
//            int conf = JOptionPane.NO_OPTION;
//            conf = JOptionPane.showConfirmDialog(rootPane, "Yakin untuk menghapus?",
//                    "Confirm!", JOptionPane.YES_NO_OPTION);
//            if (conf == JOptionPane.YES_OPTION) {
//                int baris = TBPINJAM.getSelectedRow();
//                id = Integer.valueOf(TBPINJAM.getValueAt(baris, 0).toString());
//                dao.delete(id);
//                reset();
//            }
//
//        } else {
//            JOptionPane.showMessageDialog(rootPane, "Tidak ada data yang dipilih!");
//        }
//    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        JTANGGAL = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        TXTNAMAANGGOTA = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        CBANGGOTA = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        TXTALAMAT = new javax.swing.JTextField();
        TXTNOHP = new javax.swing.JTextField();
        BTNSIMPAN = new javax.swing.JButton();
        BTNEDIT = new javax.swing.JButton();
        BTNHAPUS = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        CBPETUGAS = new javax.swing.JComboBox<>();
        TXTNAMAPETUGAS = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        TXTJABATAN = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        TXTJUDULBUKU = new javax.swing.JTextField();
        CBBUKU = new javax.swing.JComboBox<>();
        TXTPENGARANG = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        TBPINJAM = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 153, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/edit-16x16.png"))); // NOI18N
        jLabel2.setText("TANGGAL PINJAM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(182, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(JTANGGAL, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(145, 145, 145))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(JTANGGAL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(255, 153, 0));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "INPUT DATA ANGGOTA", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 14))); // NOI18N

        jLabel5.setText("ID ANGGOTA");

        jLabel6.setText("NAMA ANGGOTA");

        CBANGGOTA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        CBANGGOTA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBANGGOTAActionPerformed(evt);
            }
        });

        jLabel9.setText("ALAMAT");

        jLabel10.setText("NO.HP");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(CBANGGOTA, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(TXTNAMAANGGOTA, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TXTNOHP)
                            .addComponent(TXTALAMAT, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(CBANGGOTA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TXTNAMAANGGOTA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(TXTALAMAT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(TXTNOHP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        BTNSIMPAN.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/diskette.png"))); // NOI18N
        BTNSIMPAN.setText("SIMPAN");
        BTNSIMPAN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNSIMPANActionPerformed(evt);
            }
        });

        BTNEDIT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/document_edit.png"))); // NOI18N
        BTNEDIT.setText("EDIT");
        BTNEDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNEDITActionPerformed(evt);
            }
        });

        BTNHAPUS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/del_icon.png"))); // NOI18N
        BTNHAPUS.setText("HAPUS");
        BTNHAPUS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTNHAPUSActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/document_warning.png"))); // NOI18N
        jButton4.setText("BATAL");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon1/last_1.gif"))); // NOI18N
        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 153, 0));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "INPUT PETUGAS", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 14))); // NOI18N

        CBPETUGAS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        CBPETUGAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBPETUGASActionPerformed(evt);
            }
        });

        TXTNAMAPETUGAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTNAMAPETUGASActionPerformed(evt);
            }
        });

        jLabel3.setText("ID PETUGAS");

        jLabel4.setText("NAMA PETUGAS");

        jLabel8.setText("JABATAN ");

        TXTJABATAN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TXTJABATANActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(CBPETUGAS, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel8))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TXTNAMAPETUGAS, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                            .addComponent(TXTJABATAN))))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CBPETUGAS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TXTNAMAPETUGAS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(TXTJABATAN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 153, 0));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "INPUT DATA BUKU", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 14))); // NOI18N

        jLabel11.setText("ID BUKU");

        jLabel12.setText("JUDUL BUKU");

        jLabel13.setText("PENULIS");

        CBBUKU.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        CBBUKU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBBUKUActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                        .addComponent(CBBUKU, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel12))
                        .addGap(56, 56, 56)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TXTJUDULBUKU)
                            .addComponent(TXTPENGARANG))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(CBBUKU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(TXTJUDULBUKU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(TXTPENGARANG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(54, Short.MAX_VALUE))
        );

        TBPINJAM.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(TBPINJAM);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BTNSIMPAN)
                        .addGap(37, 37, 37)
                        .addComponent(BTNEDIT)
                        .addGap(37, 37, 37)
                        .addComponent(jButton4)
                        .addGap(40, 40, 40)
                        .addComponent(BTNHAPUS)
                        .addGap(61, 61, 61))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2))
                    .addComponent(jButton5))
                .addGap(0, 36, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(BTNSIMPAN)
                                    .addComponent(BTNEDIT)
                                    .addComponent(jButton4)
                                    .addComponent(BTNHAPUS)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton5))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        reset();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void TXTJABATANActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTJABATANActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXTJABATANActionPerformed

    private void CBPETUGASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBPETUGASActionPerformed
        // TODO add your handling code here:
        PilihPetugas();
//        try {
//            Sql = "select * from petugas where id_petugas='" + CBPETUGAS.getSelectedItem().toString() + "'";
//            st = Con.createStatement();
//            RsPetugas = st.executeQuery(Sql);
//            while (RsPetugas.next()) {
//                TXTNAMAPETUGAS.setText(RsPetugas.getString("nama_petugas"));
//                TXTJABATAN.setText(RsPetugas.getString("jabatan_petugas"));
//            }
//        } catch (Exception e) {
//        }
    }//GEN-LAST:event_CBPETUGASActionPerformed

    private void CBBUKUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBBUKUActionPerformed
        // TODO add your handling code here:
        //PilihBuku();
        try {
            Sql = "select * from buku where id_buku=?" + CBBUKU.getSelectedItem().toString() + "'";
            st = Con.createStatement();
            RsBuku = st.executeQuery(Sql);
            while (RsBuku.next()) {
                TXTJUDULBUKU.setText(RsBuku.getString("judul_buku"));//sesuaikan di database, atau bisa di ubah menjadi("nama_pelanggan")
                TXTPENGARANG.setText(RsBuku.getString("penulis_buku"));
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_CBBUKUActionPerformed

    private void CBANGGOTAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBANGGOTAActionPerformed
        // TODO add your handling code here:
        PilihAnggota();
        try {
            Sql = "select * from anggota where id_anggota='" + CBANGGOTA.getSelectedItem().toString() + "'";
            st = Con.createStatement();
            RsAnggota = st.executeQuery(Sql);
            while (RsAnggota.next()) {
                TXTNAMAANGGOTA.setText(RsAnggota.getString("nama_anggota"));//sesuaikan di database, atau bisa di ubah menjadi("nama_pelanggan")
                TXTALAMAT.setText(RsAnggota.getString("alamat_anggota"));
                TXTNOHP.setText(RsAnggota.getString("no_telp_anggota"));
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_CBANGGOTAActionPerformed


    private void BTNSIMPANActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNSIMPANActionPerformed
        // TODO add your handling code here:
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String tanggal_pinjam = sdf.format(JTANGGAL.getDate());
        DefaultTableModel model = (DefaultTableModel) TBPINJAM.getModel();
        model.addRow(new Object[]{tanggal_pinjam});

        save();
        // kodepinjam = CBBUKU.getItemAt(CBBUKU.getSelectedIndex()).toString();
//        kodepetugas = CBPETUGAS.getItemAt(CBPETUGAS.getSelectedIndex()).toString();
//        namapetugas = TXTNAMAPETUGAS.getText();
//        kodeanggota = CBANGGOTA.getItemAt(CBANGGOTA.getSelectedIndex()).toString();
//        namaanggota = TXTNAMAANGGOTA.getText();
//        //jumlahpinjam=Integer.parseInt(TXTTOTALPINJAM.getText());
////        simpandetail();
//        try {
//            Sql = "insert into peminjaman"
//                    + "(kode_peminjam,tanggal_pinjam,kode_petugas,nama_petugas,kode_anggota,nama_anggota,jumlah_pinjam)"
//                    + "values('" + kodepinjam + "',"
//                    + "'" + Tanggal + "',"
//                    + "'" + kodepetugas + "',"
//                    + "'" + namapetugas + "',"
//                    + "'" + kodeanggota + "',"
//                    + "'" + namaanggota + "',"
//                    + "'" + "')";
//            st = Con.createStatement();
//            st.execute(Sql);
//            kosongkan();
//
//            tampilpeminjaman();
//            JOptionPane.showMessageDialog(null, "Data successfully saved");
//            hapustable();
//            //BTNTAMBAH.show();
//            BTNSIMPAN.show();
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Data is not successfully saved, Data that you entered is incorrect" + e.getMessage());
//        }
    }//GEN-LAST:event_BTNSIMPANActionPerformed

    private void JTANGGALPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_JTANGGALPropertyChange
        // TODO add your handling code here:
        if (JTANGGAL.getDate() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Tanggal = format.format(JTANGGAL.getDate());
        }
    }//GEN-LAST:event_JTANGGALPropertyChange

    private void BTNHAPUSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNHAPUSActionPerformed
//        // TODO add your handling code here:
        delete();
//        kodepinjam=TXTKODEPINJAM.getText();
//        try {
//            Sql="delete from tb_peminjam "
//                    + "where kode_peminjam='"+kodepinjam+"'";
//            st=Con.createStatement();
//            st.execute(Sql);
//            kosongkan();
//            tampilpeminjaman();
//            JOptionPane.showMessageDialog(null, "Data has been Removed");
//        } catch (Exception e) {
//            JOptionPane.showConfirmDialog(null, "Data is not deleted !!"+e.getMessage());
//        
//    }                                        

    }//GEN-LAST:event_BTNHAPUSActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        new FormMenuUtama().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void TXTNAMAPETUGASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TXTNAMAPETUGASActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TXTNAMAPETUGASActionPerformed

    private void BTNEDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTNEDITActionPerformed
        // TODO add your handling code here:

        ubah();
    }//GEN-LAST:event_BTNEDITActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pinjamForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pinjamForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pinjamForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pinjamForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pinjamForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTNEDIT;
    private javax.swing.JButton BTNHAPUS;
    private javax.swing.JButton BTNSIMPAN;
    private javax.swing.JComboBox<String> CBANGGOTA;
    private javax.swing.JComboBox<String> CBBUKU;
    private javax.swing.JComboBox<String> CBPETUGAS;
    private com.toedter.calendar.JDateChooser JTANGGAL;
    private javax.swing.JTable TBPINJAM;
    private javax.swing.JTextField TXTALAMAT;
    private javax.swing.JTextField TXTJABATAN;
    private javax.swing.JTextField TXTJUDULBUKU;
    private javax.swing.JTextField TXTNAMAANGGOTA;
    private javax.swing.JTextField TXTNAMAPETUGAS;
    private javax.swing.JTextField TXTNOHP;
    private javax.swing.JTextField TXTPENGARANG;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
