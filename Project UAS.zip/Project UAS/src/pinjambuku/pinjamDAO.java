/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pinjambuku;

import java.util.List;
import javax.swing.JTable;

/**
 *
 * @author iqbal
 */
public interface pinjamDAO {
    
    public List<CBAnggota> Anggota();
    public List<CBbuku> Buku();
    public List<CBpetugas> Petugas();
    
    public void read(JTable TBPINJAM);
    public void create(pinjam pinjambuku);
    public void update(pinjam pinjambuku);
    public void delete (int id);
}
