/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ShowDaftarBuku;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;


public class ShowBukuDAOImp implements ShowBukuDAO{
   
    private Statement s;
    private koneksi con = new koneksi();
    private ResultSet rs;
    private DefaultTableModel dtm;
    private final String[] column = {"ID BUKU","JUDUL BUKU","PENULIS","PENERBIT","TAHUN TERBIT","STOK"};
    private String view = "SELECT * FROM buku";
      
    @Override
    public void read(JTable tabel){
    try {
            
            dtm = new DefaultTableModel(null, column);
            s = con.getCon().createStatement();
            rs = s.executeQuery(view);//eksekusi yg tdk merubah isi tabel
            while(rs.next()){
                Object[]col = new Object[6];
                col[0] = rs.getInt("id_buku");
                col[1] = rs.getString("judul_buku");
                col[2] = rs.getString("penulis_buku");
                col[3] = rs.getString("penerbit_buku");
                col[4] = rs.getString("tahun_terbit");
                col[5] = rs.getInt("stok");
                dtm.addRow(col);
            }
           
            tabel.setModel(dtm);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
}

    void logout() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}