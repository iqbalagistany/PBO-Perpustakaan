package SignUpAnggota;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;

public class SignUpDAOimp implements SignUpDAO {

    private koneksi con = new koneksi();
    private Statement s;
    private PreparedStatement ps;
    private ResultSet rs;
    private DefaultTableModel dtm;
    private final String[] column = {"ID", "USERNAME", "PASSWORD", "NAMA", "JURUSAN", "NO. TELP", "ALAMAT"};

    private String view = "select * from anggota";
    private String insert = "insert into anggota (username, password, nama_anggota, "
            + "jurusan_anggota, no_telp_anggota, alamat_anggota) values (?, ?, ?, ?, ?, ?)";

    private String update = "update anggota set username=?, password=?, nama_anggota=?,"
            + "jurusan_anggota=?, no_telp_anggota=?, alamat_anggota=? where id_anggota=?";
    private String delete = "delete from anggota where id_anggota=?";
    private String search = "select * from anggota where nama like %?%";

    @Override
    public void read(JTable table) {
        try {
            dtm = new DefaultTableModel(null, column);
            s = con.getCon().createStatement();
            rs = s.executeQuery(view);  //eksekusi yg tdk merubah isi tabel
            while (rs.next()) {
                Object[] col = new Object[7];
                col[0] = rs.getInt("id_anggota");
                col[1] = rs.getString("username");
                col[2] = rs.getString("password");
                col[3] = rs.getString("nama_anggota");
                col[4] = rs.getString("jurusan_anggota");
                col[5] = rs.getString("no_telp_anggota");
                col[6] = rs.getString("alamat_anggota");

                dtm.addRow(col);
            }
            table.setModel(dtm);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void create(SignUp SignUpAnggota) {
        try {
            ps = con.getCon().prepareStatement(insert);
            ps.setString(1, SignUpAnggota.getUsername());
            ps.setString(2, SignUpAnggota.getPassword());
            ps.setString(3, SignUpAnggota.getNama_anggota());
            ps.setString(4, SignUpAnggota.getJurusan_anggota());
            ps.setString(5, SignUpAnggota.getNo_telp_anggota());
            ps.setString(6, SignUpAnggota.getAlamat_anggota());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Tambah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void update(SignUp SignUpAnggota) {
        try {
            ps = con.getCon().prepareStatement(update);
            ps.setString(1, SignUpAnggota.getUsername());
            ps.setString(2, SignUpAnggota.getPassword());
            ps.setString(3, SignUpAnggota.getNama_anggota());
            ps.setString(4, SignUpAnggota.getJurusan_anggota());
            ps.setString(5, SignUpAnggota.getNo_telp_anggota());
            ps.setString(6, SignUpAnggota.getAlamat_anggota());
            
            ps.setString(7, String.valueOf(SignUpAnggota.getId_anggota()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Ubah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void delete(int id) {
        try {
            ps = con.getCon().prepareStatement(delete);
            ps.setString(1, String.valueOf(id));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Hapus data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

}
