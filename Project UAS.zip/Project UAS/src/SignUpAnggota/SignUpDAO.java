
package SignUpAnggota;

import javax.swing.JTable;


public interface SignUpDAO {
    public void read(JTable table);
    public void create(SignUp SignUpAnggota);
    public void update(SignUp SignUpAnggota);
    public void delete (int id);

}
