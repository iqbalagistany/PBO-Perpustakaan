/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IsiBukuAdmin;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;

/**
 *
 * @author HP
 */
public class IsiDataBukuDAOImp implements IsiDataBukuDAO {

    private koneksi con = new koneksi();
    private Statement s;
    private PreparedStatement ps;   //digunakan untuk menampung query yg blm lengkap datanya (yg msh ada tanda tanya)
    private ResultSet rs;
    private DefaultTableModel dtm;
    private final String[] column = {"ID BUKU", "JUDUL BUKU", "PENULIS", "PENERBIT", "TAHUN TERBIT", "STOK"};

    private String view = "select * from buku";
    private String insert = "insert into buku (judul_buku, penulis_buku,"
            + "penerbit_buku, tahun_terbit, stok) values (?, ?, ?, ?, ?)";
    private String update = "update buku set judul_buku=?, penulis_buku=?,"
            + " penerbit_buku=?, tahun_terbit=?, stok=?  where id_buku=?";
    private String delete = "delete from buku where id_buku=?";
    //private String search = "select * from buku where nama like %?%";

    @Override
    public void read(JTable table) {
        try {
            dtm = new DefaultTableModel(null, column);
            s = con.getCon().createStatement();
            rs = s.executeQuery(view);  //eksekusi yg tdk merubah isi tabel
            while (rs.next()) {
                Object[] col = new Object[6];
                col[0] = rs.getInt("id_buku");
                col[1] = rs.getString("judul_buku");
                col[2] = rs.getString("penulis_buku");
                col[3] = rs.getString("penerbit_buku");
                col[4] = rs.getInt("tahun_terbit");
                col[5] = rs.getInt("stok");
                dtm.addRow(col);
            }
            table.setModel(dtm);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void create(IsiDataBuku IsiBukuAdmin) {
        try {
            ps = con.getCon().prepareStatement(insert);
            
            ps.setString(1, IsiBukuAdmin.getJudul_buku());
            ps.setString(2, IsiBukuAdmin.getPenulis_buku());
            ps.setString(3, IsiBukuAdmin.getPenerbit_buku());
            ps.setString(4, String.valueOf(IsiBukuAdmin.getTahun_terbit()));
            ps.setString(5, String.valueOf(IsiBukuAdmin.getStok()));

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Tambah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void update(IsiDataBuku IsiBukuAdmin) {
        try {
            ps = con.getCon().prepareStatement(update);
            ps.setString(1, IsiBukuAdmin.getJudul_buku());
            ps.setString(2, IsiBukuAdmin.getPenulis_buku());
            ps.setString(3, IsiBukuAdmin.getPenerbit_buku());
            ps.setInt(4, IsiBukuAdmin.getTahun_terbit());
            ps.setInt(5, IsiBukuAdmin.getStok());
            ps.setInt(6, IsiBukuAdmin.getId_buku());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Ubah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void delete(int id) {
        try {
            ps = con.getCon().prepareStatement(delete);
            ps.setString(1, String.valueOf(id));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Hapus data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

}
