package login;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import koneksi.koneksi;

public class loginDAOImp implements loginDAO {

    private String authQuery = "select * from petugas where username = ? and password= ?";
    private String authQuery2 = "select * from anggota where username = ? and password= ?";
    
    private PreparedStatement ps;
    private ResultSet rs;
    private final koneksi koneksi = new koneksi();

    @Override
    public void login(String username, String password) {
        
        
        try {
            ps = koneksi.getCon().prepareStatement(authQuery);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            while (rs.next()) {
                login.AUTH = true;
                login.NAMA = rs.getString("nama_petugas");
                login.USER_ID = rs.getInt("id_petugas");
            }
        } catch (Exception ex) {
            //Logger.getLogger(LoginDAOImp.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }

    }

    @Override
    public void logout() {

        login.AUTH = false;
        login.NAMA = "";
        login.USER_ID = 0;
        login.STATUS = "";
    }

    @Override
    public void login2(String username, String password) {
        try {
            ps = koneksi.getCon().prepareStatement(authQuery2);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            while (rs.next()) {
                login2.AUTH = true;
                login2.NAMA = rs.getString("nama_anggota");
                login2.USER_ID = rs.getInt("id_anggota");
            }
        } catch (Exception ex) {
            //Logger.getLogger(LoginDAOImp.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
}
