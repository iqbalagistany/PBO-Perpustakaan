
package login;


public interface loginDAO {

public void login(String username, String password);
public void login2(String username, String password);
public void logout();

}