/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IsiPeminjamAdm;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import koneksi.koneksi;
import java.sql.Date;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;

/**
 *
 * @author HP
 */
public class IsiDataPeminjamanDAOImp implements IsiDataPeminjamanDAO {

    private koneksi con = new koneksi();
    
    
    private JDateChooser chooser;
    private Statement s;
    private PreparedStatement ps;   //digunakan untuk menampung query yg blm lengkap datanya (yg msh ada tanda tanya)
    private ResultSet rs;
    private DefaultTableModel dtm;
    private final String[] column = {"ID PEMINJAM", "TANGGAL PINJAM", "ID BUKU", "ID ANGGOTA", "ID PETUGAS"};
    private String view = "select * from peminjaman";
    private String insert = "insert into peminjaman (id_peminjam, tanggal_pinjam,"
            + "id_buku, id_anggota, id_petugas) values (?, ?, ?, ?, ?)";
    private String update = "update peminjaman set tanggal_pinjam=?, id_buku=?,"
            + " id_anggota=?, id_petugas=? where id_peminjaman=?";
    private String delete = "delete from petugas where id_peminjaman=?";

    @Override
    public void read(JTable TBPINJAM) {
        try {
            dtm = new DefaultTableModel(null, column);
            s = con.getCon().createStatement();
            rs = s.executeQuery(view);  //eksekusi yg tdk merubah isi tabel
            while (rs.next()) {
                Object[] col = new Object[5];
                col[0] = rs.getInt("id_peminjam");
                col[1] = rs.getString("tanggal_pinjam");
                col[2] = rs.getString("id_buku");
                col[3] = rs.getString("id_anggota");
                col[4] = rs.getInt("id_petugas");

                dtm.addRow(col);
            }
            TBPINJAM.setModel(dtm);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void create(IsiDataPeminjaman IsiPeminjamAdm) {
        try {
            ps = con.getCon().prepareStatement(insert);

            ps.setInt(1, IsiPeminjamAdm.getId_peminjaman());
            ps.setString(2, IsiPeminjamAdm.getTanggal_pinjam());
            ps.setInt(3, IsiPeminjamAdm.getId_buku());
            ps.setInt(4, IsiPeminjamAdm.getId_anggota());
            ps.setInt(5, IsiPeminjamAdm.getId_petugas());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Tambah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void update(IsiDataPeminjaman IsiPeminjamAdm) {
        try {
            ps = con.getCon().prepareStatement(update);
            ps.setInt(1, IsiPeminjamAdm.getId_peminjaman());
            ps.setString(2, IsiPeminjamAdm.getTanggal_pinjam());
            ps.setInt(3, IsiPeminjamAdm.getId_buku());
            ps.setInt(4, IsiPeminjamAdm.getId_anggota());
            ps.setInt(5, IsiPeminjamAdm.getId_petugas());

            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Ubah data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }

    @Override
    public void delete(int id) {
        try {
            ps = con.getCon().prepareStatement(delete);
            ps.setString(1, String.valueOf(id));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Hapus data berhasil ^^");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
}
